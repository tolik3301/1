# Windows-CRD


### How to use

Just Fork this Repository, Go to Actions tab, Select the _Windows-CRD_ workflow. Then select **Run Workflow** fill the following data in CRD Code and your Pin in the fields. After that, Press Start.

Input the following code in the fields.

- Get the **Windows (Powershell)** command from here:

  https://remotedesktop.google.com/headless
  
- Enter you Six digit Pin code to Login

  (_Any Six digit Pin_)

**Thats it...** After 2-3 min of Initialize, Check your CRD Application or Account.

## Credits

Initial Bringup and Improvements by Team [Area69Lab](https://github.com/Area69Lab) and [Alone](https://t.me/Alone215)
